import numpy as np
import scipy.sparse as sp
import torch


def sum_edge_TM_optimized():
    # 数据加载
    prefix = r"G:\OtherCode\__dataset\多类多关系\阿里多类多关系数据"
    A = sp.load_npz(prefix + "/adjM.npz").toarray()

    A_PU = torch.tensor(A[:9000, 9000:9000 + 19865], dtype=torch.float32).cuda()  # P到U的子矩阵
    A_UP = torch.tensor(A[9000:9000 + 19865, :9000], dtype=torch.float32).cuda()  # U到P的子矩阵
    A_UA = torch.tensor(A[9000:9000 + 19865, 9000 + 19865+72:], dtype=torch.float32).cuda()  # U到A的子矩阵
    A_AU = torch.tensor(A[9000 + 19865+72:, 9000:9000 + 19865], dtype=torch.float32).cuda()  # A到U的子矩阵

    # temp1 = torch.matmul(A_PU, A_UA)  # Shape: [9000, 72]
    #
    # temp2 = torch.matmul(temp1, A_AU)  # Shape: [9000, 19865]
    # result = torch.matmul(temp2, A_UP)  # Shape: [9000, 9000]
    result = torch.matmul(A_PU,A_UP)
    result_np = result.cpu().numpy()
    np.save(prefix + "/sum_edge_pup.npy", result_np)

    print("沿着PUAUP路径的边权重总和矩阵：\n", result_np)
    print("边权重总和：", np.sum(result_np))
    print("end")


if __name__ == "__main__":
    sum_edge_TM_optimized()
