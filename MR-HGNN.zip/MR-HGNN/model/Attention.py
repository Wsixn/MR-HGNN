import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import Parameter
import math
import torch


class SemanticAttention(nn.Module):
    def __init__(self, in_size, hidden_size=128):  #64,128
        super(SemanticAttention, self).__init__()
        self.project = nn.Sequential(nn.Linear(in_size, hidden_size), nn.Tanh(), nn.Linear(hidden_size, 1, bias=False))# 64,128  -->  128,1
    def forward(self, z):
        #z.shape（4019,2,64）
        w = self.project(z).mean(0)     #w.shape(2,1)  经过project变成（4019,2,1） 在经过mean变成（2,1）
        beta = torch.softmax(w, dim=0)
        beta = beta.expand((z.shape[0],) + beta.shape)
        return (beta * z).sum(1)


class GCN(nn.Module):
    def __init__(self, hidden_dim, bias=True):
        super(GCN, self).__init__()
        self.Weight = Parameter(torch.FloatTensor(hidden_dim, hidden_dim)).data
        if bias:
            self.Bias = Parameter(torch.FloatTensor(hidden_dim)).data
        else:
            self.register_parameter('bias', True)
        self.reset_parameters()
        self.non_linear = nn.ReLU()
    def reset_parameters(self,):
        stdv = 1. / math.sqrt(self.Weight.size(1))
        self.Weight.data.uniform_(-stdv, stdv)
        if self.Bias is not None:
            self.Bias.data.uniform_(-stdv, stdv)
    def forward(self, inputs, adj):
        output = self.non_linear(torch.spmm(adj, self.non_linear(torch.spmm(inputs, self.Weight))))
        if self.Bias is not None:
            output = output + self.Bias
        return output