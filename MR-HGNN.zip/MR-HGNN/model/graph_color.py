import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
import random
import scipy.sparse as sp
import os
'''
方法1：使用多种颜色
'''
# def greedy_coloring(adj_matrix):
#     """
#     使用贪心算法为图的邻接矩阵进行着色
#     :param adj_matrix: 图的邻接矩阵
#     :return: 每个顶点的颜色列表
#     """
#     n = adj_matrix.shape[0]  # 获取顶点数量
#     colors = [-1] * n  # 初始化颜色列表，-1表示未着色
#     colors[0] = 0  # 第一个顶点着色为 0
#
#     # 存储可用的颜色
#     available_colors = [False] * n
#
#     for u in range(1, n):
#         # 将与 u 相邻的顶点的颜色标记为不可用
#         for v in range(n):
#             if adj_matrix[u][v] == 1 and colors[v] != -1:
#                 available_colors[colors[v]] = True
#
#                 # 寻找第一个可用的颜色
#         for color in range(n):
#             if not available_colors[color]:
#                 colors[u] = color
#                 break
#
#                 # 重置可用颜色列表
#         available_colors = [False] * n
#
#     return colors

'''
方法2：使用不超过4种颜色
'''

def greedy_coloring(adj_matrix):
    n = adj_matrix.shape[0]  # 获取顶点数量
    colors = [-1] * n  # 初始化颜色列表
    colors[0] = 0  # 第一个顶点着色为 0

    # 实际可用的颜色限制在 4 种
    max_colors = 4
    available_colors = [False] * max_colors

    for u in range(1, n):
        # 将与 u 相邻的顶点的颜色标记为不可用
        for v in range(n):
            if adj_matrix[u][v] == 1 and colors[v] != -1:
                if colors[v] < max_colors:  # 确保不会超出最大颜色限制
                    available_colors[colors[v]] = True

                    # 寻找第一个可用的颜色
        for color in range(max_colors):
            if not available_colors[color]:
                colors[u] = color
                break

                # 重置可用颜色列表
        available_colors = [False] * max_colors

    return colors


def feat_add_color(prefix,adj_matrix,feat,type1,type2,type3=0,type4=0,type5=0):
    feature0 = feat
    file_path = prefix+"/feature0_color.npy"
    if os.path.isfile(file_path):
        print("文件存在。")
        feature0_color = np.load(prefix+"/feature0_color.npy")
        feature1_color = np.load(prefix+"/feature1_color.npy")
        feature2_color = np.load(prefix+"/feature2_color.npy")
        feature3_color = np.load(prefix+"/feature3_color.npy")
    else:
        colors = greedy_coloring(adj_matrix)
        print("各顶点着色结果:", colors)
        print(max(colors))

        from sklearn.preprocessing import OneHotEncoder

        encoder = OneHotEncoder(sparse=False)
        # 转换颜色标签
        color_labels_encoded = encoder.fit_transform(np.array(colors).reshape(-1, 1))
        # 合并原始特征与编码后的一热向量
        # combined_features = np.hstack((feature0, color_labels_encoded[0:type1]))
        # print("合并后的特征矩阵:", combined_features)
        # return combined_features
        feature0_color = color_labels_encoded[0:type1]
        feature1_color = color_labels_encoded[type1:type2]
        feature2_color = color_labels_encoded[type2:type3]
        feature3_color = color_labels_encoded[type3:type4]
        print("feature0 color:",feature0_color)
        print("feature1 color:",feature1_color)
        print("feature2 color:",feature2_color)
        print("feature3 color:",feature3_color)
        np.save(prefix+"/feature0_color.npy",feature0_color)
        np.save(prefix+"/feature1_color.npy",feature1_color)
        np.save(prefix+"/feature2_color.npy",feature2_color)
        np.save(prefix+"/feature3_color.npy",feature3_color)

    return(feature0_color,feature1_color,feature2_color,feature3_color)