import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from dgl.nn.pytorch import GraphConv,GATConv
from Attention import GCN, SemanticAttention

class Color_Path(nn.Module):
    def __init__(self,hid_dim,out_dim,path_num,color_dim,dropout=0.5):
        super(Color_Path, self).__init__()
        self.hid_dim = hid_dim
        self.path_num = path_num
        self.gcn = nn.ModuleList([GCN(color_dim) for i in range(path_num)])

    def forward(self,weight_Path,feature0_color,paths_coding):
        feat_color = []
        for i in range(self.path_num):
            weight_Path[i] = (weight_Path[i] > 0) * 1.0
            color = self.gcn[i](feature0_color,weight_Path[i])
            #将color与path_coding拼接
            color_pathcoding = torch.cat((color,paths_coding[i]),dim=1)
            feat_color.append(color_pathcoding)
        return feat_color

class Path_AGG(nn.Module):
    def __init__(self,hid_dim,out_dim,path_num,dropout=0.5):
        super(Path_AGG, self).__init__()
        self.path_num = path_num
        self.gcn = nn.ModuleList([GCN(hid_dim) for i in range(path_num)])

    def forward(self,weight_Path,h,path_leng):
        path_agg = []
        for i in range(self.path_num):
            #找出最大值
            max_values = weight_Path[i].max(dim=1).values
            # 替换原来邻接矩阵的对角线元素
            weight_Path[i][range(weight_Path[i].size(0)), range(weight_Path[i].size(1))] = max_values
            # 除以路径长度进行归一化
            weight_Path[i] /= (path_leng[i]-1)
            # weight_Path[i] = (weight_Path[i]>0)*1.0
            path_agg.append(self.gcn[i](h,weight_Path[i]))
        return path_agg


class Feat_Fusion(nn.Module):
    def __init__(self,hid_dim,out_dim,path_num,path_leng,type_leng,color_dim,dropout=0.5):
        super(Feat_Fusion, self).__init__()
        self.path_num = path_num
        self.path_leng = path_leng
        self.type_leng = type_leng
        #特征对齐
        self.aligment = nn.ModuleList([nn.Linear(hid_dim+type_leng*path_leng[i]+color_dim,hid_dim) for i in range(len(path_leng))])

        #语义级融合
        self.semantic = SemanticAttention(hid_dim)
        self.no_linear = nn.Tanh()

    def forward(self,h_colo_path,h_weigh_agg):
        #先将颜色跟路径编码与特征进行拼接
        feat_color_path = [torch.cat((h_colo_path[i],h_weigh_agg[i]),dim=1) for i in range(self.path_num)]
        #特征对齐
        feat_aligment = [self.no_linear(self.aligment[i](feat_color_path[i])) for i in range(self.path_num)]    #本行增加激活函数后准确率极大提升（tanh）
        semantic_embeddings = torch.stack(feat_aligment, dim=1)  # 得到（4019,2,64）其中2是因为有两个元路径,已经不再是一个列表了，变成了torch
        z = self.semantic(semantic_embeddings)
        return z


class models(nn.Module):
    def __init__(self,in_dim,hid_dim,out_dim,path_num,path_leng,type_leng,color_dim,dropout=0.5):
        super(models, self).__init__()
        self.linear = nn.Linear(in_dim,hid_dim)
        self.no_linear = nn.Tanh()
        self.drop = nn.Dropout(p=dropout)
        self.out = nn.Linear(hid_dim,out_dim)
        self.path_num = path_num
        self.path_leng = path_leng

        #定义着色聚合层
        self.color_path = Color_Path(hid_dim,hid_dim,path_num,color_dim)
        self.path_embd = Path_AGG(hid_dim,out_dim,path_num)
        #此处需要计算路径嵌入下的长度，并将其传递给特征融合层

        self.feat_fusion = Feat_Fusion(hid_dim,out_dim,path_num,path_leng,type_leng,color_dim)


    def forward(self,weight_Path, feature,feature0_color,paths_coding):
        h = self.linear(feature)
        h_colo_path = self.color_path(weight_Path,feature0_color,paths_coding)
        h_weigh_agg = self.path_embd(weight_Path,h,self.path_leng)
        z = self.feat_fusion(h_colo_path,h_weigh_agg)
        return  self.out(z),z



