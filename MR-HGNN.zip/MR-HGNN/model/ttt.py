import scipy.sparse as sp

prefix=r"G:\OtherCode\__dataset\多类多关系\音乐数据集2.0"
M_L = sp.load_npz(prefix+"/song-language_matrix.npz")
M_P = sp.load_npz(prefix+"/song-publish_time_matrix.npz")
M_L_t1 = sp.load_npz(prefix+"/song-user_type1_play_matrix.npz")
M_L_t2 = sp.load_npz(prefix+"/song-user_type2_download_matrix.npz")
M_L_t3 = sp.load_npz(prefix+"/song-user_type3_collect_matrix.npz")
adj = sp.load_npz(prefix + "/adjM.npz").toarray()

MLM = M_L * M_L.T
MPM = M_P * M_P.T
MLM_play = M_L_t1 * M_L_t1.T
MLM_down = M_L_t2 * M_L_t2.T
MLM_collect = M_L_t3 * M_L_t3.T
print("计算成功")
sp.save_npz(prefix+"/MLM.npz",MLM)
sp.save_npz(prefix+"/MPM.npz",MPM)
sp.save_npz(prefix+"/MLM_play.npz",MLM_play)
sp.save_npz(prefix+"/MLM_down.npz",MLM_down)
sp.save_npz(prefix+"/MLM_collect.npz",MLM_collect)
print("保存成功")



