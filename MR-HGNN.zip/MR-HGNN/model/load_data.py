import sys

import numpy as np
import matplotlib.pyplot as plt
import scipy
import pickle
import torch
import dgl
import torch.nn.functional as F
import torch as th
import scipy.sparse as sp
from sklearn.manifold import TSNE
from graph_color import feat_add_color


def load_TM_Shop(prefix=r"G:\OtherCode\__dataset\多类多关系\阿里多类多关系数据"):
    adj = sp.load_npz(prefix + "/adjM.npz").toarray()
    features_0 = sp.load_npz(prefix+"/product_feature.npz").toarray()
    # features_1 = sp.load_npz(prefix+"/user_feature.npz").toarray()
    # features_2 = torch.eye(72)
    # features_3 = torch.eye(9)
    features_0 = torch.FloatTensor(features_0)
    # features_1 = torch.FloatTensor(features_1)
    # features = [features_0, features_1, features_2, features_3]
    features_color = feat_add_color(prefix,adj,features_0,9000,9000+19865,9000+19865+72,9000+19865+72+9)
    feature0_color = torch.FloatTensor(features_color[0])
    # 标签 训练集，验证集，测试集 分类数量
    labels = np.load(prefix + '/labels.npy')
    labels = torch.LongTensor(labels)
    train_val_test_idx = np.load(prefix + '/train_val_test_idx.npz')
    train_idx = train_val_test_idx['train_idx']
    val_idx = train_val_test_idx['val_idx']
    test_idx = train_val_test_idx['test_idx']

    train_idx = torch.from_numpy(train_idx).to(torch.int64)
    val_idx = torch.from_numpy(val_idx).to(torch.int64)
    test_idx = torch.from_numpy(test_idx).to(torch.int64)
    num_classes = 3


    edgeNum_PUAUP = np.load(prefix+"/sum_edge_puaup.npy")
    edgeNum_PUCUP = np.load(prefix+"/sum_edge_pucup.npy")
    edgeNum_PUP = np.load(prefix+"/sum_edge_pup.npy")
    edgeNum_PUAUP = torch.from_numpy(edgeNum_PUAUP).type(torch.FloatTensor)
    edgeNum_PUCUP = torch.from_numpy(edgeNum_PUCUP).type(torch.FloatTensor)
    edgeNum_PUP = torch.from_numpy(edgeNum_PUP).type(torch.FloatTensor)
    weight_Path =[edgeNum_PUAUP,edgeNum_PUCUP,edgeNum_PUP]

    #路径编码
    # 定义节点类型到one-hot编码的映射
    node_type_to_one_hot = {
        'P': [1, 0, 0, 0],
        'U': [0, 1, 0, 0],
        'A': [0, 0, 1, 0],
        'C': [0, 0, 0, 1]
    }

    # 定义路径
    paths = ['PUP','PUAUP', 'PUCUP']

    # 生成路径编码的函数
    def encode_path_with_one_hot(path, node_type_to_one_hot):
        # 将每个节点的one-hot编码连接起来
        encoded_path = []
        for node in path:
            encoded_path.extend(node_type_to_one_hot[node])
        return encoded_path

    # 生成所有路径的编码
    encoded_paths = {path: encode_path_with_one_hot(path, node_type_to_one_hot) for path in paths}

    # 输出路径编码结果，此时结果只是一维列表
    for path, encoded_path in encoded_paths.items():
        print(f"Path: {path} -> Encoded Path: {encoded_path}")

    # 定义扩展函数，将1维列表扩展到9000维度
    def expand_to_tensor(value, num_rows=9000):
        # 将列表转换为NumPy数组
        array = np.array(value)
        # 重复数组以扩展到9000行
        expanded_array = np.tile(array, (num_rows, 1))
        # 转换为PyTorch张量
        tensor = torch.tensor(expanded_array, dtype=torch.float32)
        return tensor

    # 使用扩展函数将字典中的每个值（一维向量路径编码) 扩展成9000维，与特征矩阵相匹配
    paths_coding = [expand_to_tensor(value) for key, value in encoded_paths.items()]
    path_leng = [3,5,5]     #路径的长度/跳数
    type_leng = 4
    color_dim=3



    return weight_Path, features_0,feature0_color,paths_coding, labels, num_classes, train_idx, val_idx, test_idx,path_leng,type_leng,color_dim


def load_AL_Music(prefix=r"G:\OtherCode\__dataset\多类多关系\音乐数据集2.0"):
    adj = sp.load_npz(prefix + "/adjM.npz").toarray()
    features_0 = np.load(prefix+"/song_features2.npy")
    features_0 = torch.FloatTensor(features_0)
    features_color = feat_add_color(prefix,adj,features_0,9944,9944+75756,9944+75756+6,9944+75756+6+532)
    feature0_color = torch.FloatTensor(features_color[0])
    # 标签 训练集，验证集，测试集 分类数量
    labels = np.load(prefix + '/labels.npy')
    labels = torch.LongTensor(labels)
    train_val_test_idx = np.load(prefix + '/train_val_test_idx.npz')
    train_idx = train_val_test_idx['train_idx']
    val_idx = train_val_test_idx['val_idx']
    test_idx = train_val_test_idx['test_idx']

    train_idx = torch.from_numpy(train_idx).to(torch.int64)
    val_idx = torch.from_numpy(val_idx).to(torch.int64)
    test_idx = torch.from_numpy(test_idx).to(torch.int64)
    num_classes = 10


    MLM = sp.load_npz(prefix+"/MLM.npz").toarray()
    MPM = sp.load_npz(prefix+"/MPM.npz").toarray()
    MUM_play = sp.load_npz(prefix+"/MUM_play.npz").toarray()
    MUM_down = sp.load_npz(prefix+"/MUM_down.npz").toarray()
    MUM_collect = sp.load_npz(prefix+"/MUM_collect.npz").toarray()

    MLM = torch.from_numpy(MLM).type(torch.FloatTensor)
    MPM = torch.from_numpy(MPM).type(torch.FloatTensor)
    MUM_play = torch.from_numpy(MUM_play).type(torch.FloatTensor)
    MUM_down = torch.from_numpy(MUM_down).type(torch.FloatTensor)
    MUM_collect = torch.from_numpy(MUM_collect).type(torch.FloatTensor)
    weight_Path =[MLM,MPM,MUM_play+MUM_down+MUM_collect]

    #路径编码
    # 定义节点类型到one-hot编码的映射
    node_type_to_one_hot = {
        'M': [1, 0, 0, 0],
        'U': [0, 1, 0, 0],
        'L': [0, 0, 1, 0],
        'P': [0, 0, 0, 1]
    }

    # 定义路径
    paths = ['MUM','MLM', 'MPM']

    # 生成路径编码的函数
    def encode_path_with_one_hot(path, node_type_to_one_hot):
        # 将每个节点的one-hot编码连接起来
        encoded_path = []
        for node in path:
            encoded_path.extend(node_type_to_one_hot[node])
        return encoded_path

    # 生成所有路径的编码
    encoded_paths = {path: encode_path_with_one_hot(path, node_type_to_one_hot) for path in paths}

    # 输出路径编码结果，此时结果只是一维列表
    for path, encoded_path in encoded_paths.items():
        print(f"Path: {path} -> Encoded Path: {encoded_path}")

    # 定义扩展函数，将1维列表扩展到9000维度
    def expand_to_tensor(value, num_rows=9944):
        # 将列表转换为NumPy数组
        array = np.array(value)
        # 重复数组以扩展到9000行
        expanded_array = np.tile(array, (num_rows, 1))
        # 转换为PyTorch张量
        tensor = torch.tensor(expanded_array, dtype=torch.float32)
        return tensor

    # 使用扩展函数将字典中的每个值（一维向量路径编码) 扩展成9000维，与特征矩阵相匹配
    paths_coding = [expand_to_tensor(value) for key, value in encoded_paths.items()]
    path_leng = [3,3,3]     #路径的长度/跳数
    type_leng = 4
    color_dim=2



    return weight_Path, features_0,feature0_color,paths_coding, labels, num_classes, train_idx, val_idx, test_idx,path_leng,type_leng,color_dim



if __name__ == "__main__":
    load_AL_Music()
